from django.urls import path
from . import views
from .views import cancel_booking

urlpatterns = [
    path("equipmentManagement/", views.equipmentManagement, name="equipmentManagement"),

    path("updateItem/<str:id>", views.updateItem, name="updateItem"),
    path("createItem/", views.createItem, name="createItem"),
    path("deleteItem/<str:id>/", views.deleteItem, name="deleteItem"),
  path("equipmentView/", views.equipmentView, name = "equipmentView"),
  path('book_item/<int:item_id>/', views.book_item, name='book_item'),
  path('bookings/', views.bookings_view, name='bookings_view'),
      path('historical/', views.historical, name='historical'),
    path('rebook/<int:item_id>/', views.rebook, name='rebook'),
     path('cancel_booking/<int:booking_id>/', cancel_booking, name='cancel_booking'),
    path("bookings/<int:booking_id>/update/", views.booking_update, name="booking_update"),
    path("bookings/<int:booking_id>/delete/", views.booking_delete, name="deleteBooking"),
    path("bookings/create/", views.booking_create, name="createBooking"),
    path('userManagement/', views.user_management, name='user_management'),
    path('update_user/<int:pk>/', views.update_user, name='update_user'),
    path('delete_user/<int:pk>/', views.delete_user, name='delete_user'),
    path("reports/", views.reports, name="reports"),
    path('bookingManagement/', views.booking_management, name='booking_management'),
    path('add_user/', views.add_user, name='add_user'),
]
