from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from django.db.models import Q, Count
from .forms import BookingAdminForm, BookingUserForm, CreateItemForm, UpdateItemForm
from .models import Item, Booking, ItemType, ItemStatus
from django.utils import timezone

@login_required
def equipmentManagement(request):
    itemtypes = ItemType.objects.all()
    itemstatus = ItemStatus.objects.all()

    q = request.GET.get('q') if request.GET.get('q') is not None else ""
    item = Item.objects.filter(
        Q(type__type__icontains=q) |
        Q(name__icontains=q) |
        Q(deviceSerialNumber__icontains=q) |
        Q(CPU__icontains=q) |
        Q(GPU__icontains=q) |
        Q(RAM__icontains=q) |
        Q(location__icontains=q) |
        Q(status__status__icontains=q)
    )
    totalInventory = item.count()

    context = {'item': item, 'itemtypes': itemtypes, 'itemstatus': itemstatus, 'totalInventory': totalInventory}
    return render(request, "equipmentManagement.html", context)


@login_required
def equipmentView(request):
    itemtypes = ItemType.objects.all()
    itemstatus = ItemStatus.objects.all()

    q = request.GET.get('q') if request.GET.get('q') is not None else ""
    status_filter = request.GET.get('status')
    type_filter = request.GET.get('type')
    sort_by = request.GET.get('sort')

    items = Item.objects.filter(
        Q(type__type__icontains=q) |
        Q(name__icontains=q) |
        Q(deviceSerialNumber__icontains=q) |
        Q(CPU__icontains=q) |
        Q(GPU__icontains=q) |
        Q(RAM__icontains=q) |
        Q(location__icontains=q) |
        Q(status__status__icontains=q)
    )

    if status_filter:
        items = items.filter(status__status=status_filter)
    if type_filter:
        items = items.filter(type__type=type_filter)
    if sort_by:
        items = items.order_by(sort_by)

    totalInventory = items.count()

    # Create a BookingForm instance
    booking_form = BookingUserForm()

    context = {
        'items': items,
        'itemtypes': itemtypes,
        'itemstatus': itemstatus,
        'totalInventory': totalInventory,
        'booking_form': booking_form  # Add the booking form to the context
    }
    return render(request, 'equipmentView.html', context)


@login_required
def book_item(request, item_id):
    item = get_object_or_404(Item, pk=item_id)

    if request.method == 'POST':
        form = BookingUserForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.item = item
            booking.user = request.user
            booking.save()
            # Check if item.quantity is not None before converting it to an integer
            if item.quantity is not None:
                item.quantity = int(item.quantity)
                item.quantity -= 1
                item.save()  # Save the updated item
            messages.success(request, 'Equipment booked successfully!')
            return redirect('bookings_view')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
    else:
        form = BookingUserForm()

    return render(request, 'booking_form.html', {'form': form, 'item': item})


@login_required
def bookings_view(request):
    current_bookings = Booking.objects.filter(user=request.user, end_date__gte=timezone.now().date())
    return render(request, 'bookings.html', {'bookings': current_bookings})


def historical(request):
    historical_bookings = Booking.objects.filter(end_date__lt=timezone.now().date())
    return render(request, 'historical.html', {'historical_bookings': historical_bookings})


@login_required
def rebook(request, item_id):
    item = get_object_or_404(Item, pk=item_id)
    if request.method == 'POST':
        form = BookingUserForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.item = item
            booking.user = request.user
            booking.save()
            # Check if item.quantity is not None before converting it to an integer
            if item.quantity is not None:
                item.quantity = int(item.quantity)
                item.quantity -= 1
                item.save()  # Save the updated item
            messages.success(request, 'Equipment booked successfully!')
            return redirect('bookings_view')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
    else:
        form = BookingUserForm()

    return render(request, 'booking_form.html', {'form': form, 'item': item})


@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, pk=booking_id)
    if request.method == 'POST':
        booking.delete()
        messages.success(request, 'Booking canceled successfully!')
        return redirect('bookings_view')
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))


def booking_management(request):
    bookings = Booking.objects.all()

    if request.method == 'POST':
        form = BookingAdminForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Booking created successfully!')
            return redirect('bookingManagement.html')
        else:
            messages.error(request, 'Form is not valid. Please check the input data.')
    else:
        form = BookingAdminForm()

    return render(request, 'bookingManagement.html', {'bookings': bookings, 'form': form})


def updateItem(request, id):
    item = Item.objects.get(id=id)
    listitem = Item.objects.get(id=id)
    if request.method == "POST":
        form = UpdateItemForm(request.POST, instance=listitem)
        if form.is_valid():
            listitem.save()
            return redirect('equipmentManagement')
    else:
        form = UpdateItemForm(instance=listitem)
    context = {'listitem': listitem, 'form': form, 'item': item}
    return render(request, "updateItem.html", context)


def createItem(request):
    if request.method == "POST":
        form = CreateItemForm(request.POST)
        if form.is_valid():
            form = form.save()
            return redirect("equipmentManagement")
    else:
        form = CreateItemForm()
    return render(request, "createItem.html", {"form": form})


def deleteItem(request, id):
    item = Item.objects.get(id=id)
    if request.method == "POST":
        item.delete()
        return redirect('equipmentManagement')
    return render(request, "deleteItem.html", {'item': item})


def booking_create(request):
    if request.method == 'POST':
        form = BookingAdminForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Booking created successfully!')
            return redirect('booking_management')  # Redirect to 'booking_management'
        else:
            messages.error(request, 'Form is not valid. Please check the input data.')
    else:
        form = BookingAdminForm()
    return render(request, 'booking_create.html', {'form': form})


def booking_update(request, booking_id):
    booking = get_object_or_404(Booking, pk=booking_id)
    if request.method == 'POST':
        form = BookingAdminForm(request.POST, instance=booking)
        if form.is_valid():
            form.save()
            messages.success(request, 'Booking updated successfully!')
            return redirect('booking_management')
    else:
        form = BookingAdminForm(instance=booking)
    return render(request, 'booking_update.html', {'form': form, 'booking': booking})


def booking_delete(request, booking_id):
    booking = get_object_or_404(Booking, pk=booking_id)
    if request.method == 'POST':
        booking.delete()
        messages.success(request, 'Booking deleted successfully!')
        return redirect('booking_management')
    return render(request, 'booking_delete.html', {'booking': booking})


def reports(request):
    totalInventory = Item.objects.count()
    typesInventory = ItemType.objects.annotate(count=Count("item"))
    context = {'totalInventory': totalInventory, 'typesInventory': typesInventory}
    return render(request, "reports.html", context)
