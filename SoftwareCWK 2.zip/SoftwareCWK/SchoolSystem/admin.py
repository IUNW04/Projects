from django.contrib import admin
from .models import Item, ItemType, ItemStatus, Booking

admin.site.register(Item)
admin.site.register(ItemType)
admin.site.register(ItemStatus)
admin.site.register(Booking)
